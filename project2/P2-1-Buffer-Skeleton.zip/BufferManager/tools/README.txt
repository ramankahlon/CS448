Third party software tools:

* Java Compiler Compiler [tm], version 4.0
  https://javacc.dev.java.net/

  Necessary for modifying the SQL parser (see src/parser/README.txt).

* RetroGuard Java Obfuscation, version 2.2.0
  http://www.retrologic.com/

  See the lib directory for examples of obfuscating jar files.
